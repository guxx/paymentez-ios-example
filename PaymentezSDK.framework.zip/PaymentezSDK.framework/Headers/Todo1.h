//
//  Todo1.h
//  PaymentezSDK
//
//  Created by Gustavo Sotelo on 09/09/16.
//  Copyright © 2016 Paymentez. All rights reserved.
//

#import "MobileAPI.h"

@interface Todo1 : NSObject  {
@private
    NSArray *mInfoItems;
    NSArray *mJsonKeys;
    NSArray *mSpecialCommands;
    
    NSArray *mJsonLocationKeys;
    
    MobileAPI *mMobileAPI;
    BOOL mMobileAPIInitialized;
    NSString *mJSONInfoString;
    int mConfiguration;
}
-(void)initMobileSDK;
-(NSString *)collect;
@end
